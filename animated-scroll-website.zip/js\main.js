/**
 * AETHERIA // MAIN ORCHESTRATION & ANIMATIONS
 * Powered by Lenis, GSAP, and ScrollTrigger
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide Icons
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // Register GSAP plugins
  gsap.registerPlugin(ScrollTrigger);

  // Initialize Lenis Virtual Scroll
  const lenis = new Lenis({
    duration: 1.2,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    orientation: 'vertical',
    gestureOrientation: 'vertical',
    smoothWheel: true,
    wheelMultiplier: 1.0,
    touchMultiplier: 1.8
  });

  // Sync Lenis with GSAP ScrollTrigger
  lenis.on('scroll', (e) => {
    ScrollTrigger.update();
    handleScrollProgress(e);
  });

  gsap.ticker.add((time) => {
    lenis.raf(time * 1000);
  });
  gsap.ticker.lagSmoothing(0);

  // Handle Internal Anchor Clicks with Smooth Lenis Scroll
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        e.preventDefault();
        lenis.scrollTo(targetElement, {
          offset: targetId === '#hero' ? 0 : -60,
          duration: 1.4
        });
      }
    });
  });

  // Back to top CTA button
  const scrollTopBtn = document.getElementById('scrollTopBtn');
  if (scrollTopBtn) {
    scrollTopBtn.addEventListener('click', () => {
      lenis.scrollTo('#hero', { duration: 1.6 });
    });
  }

  // Launch button dynamic feedback
  const launchBtn = document.getElementById('launchExperienceBtn');
  const launchCoreBtn = document.getElementById('launchCoreBtn');
  [launchBtn, launchCoreBtn].forEach((btn) => {
    if (!btn) return;
    btn.addEventListener('click', (e) => {
      if (window.soundEngine) {
        window.soundEngine.playChord([440, 554.37, 659.25, 880]);
      }
      if (window.particleEngine) {
        window.particleEngine.triggerWarpBurst();
      }
    });
  });

  /* --------------------------------------------------------------------------
     SCROLL PROGRESS & TELEMETRY HUD
  -------------------------------------------------------------------------- */
  const progressBar = document.getElementById('scrollProgressBar');
  const telemetryPct = document.getElementById('telemetryScrollPct');

  function handleScrollProgress(e) {
    const scrollY = window.scrollY || window.pageYOffset;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = Math.max(0, Math.min(1, scrollY / (docHeight || 1)));
    const pct = Math.round(progress * 100);

    if (progressBar) {
      progressBar.style.width = `${progress * 100}%`;
    }

    if (telemetryPct) {
      telemetryPct.textContent = `${pct}%`;
    }

    // Pass scroll velocity into particle engine & play subtle audio tick
    if (window.particleEngine && e.velocity) {
      window.particleEngine.injectScrollVelocity(e.velocity);
    }
    if (window.soundEngine && Math.abs(e.velocity) > 0.6) {
      window.soundEngine.playScrollTick();
    }
  }

  /* --------------------------------------------------------------------------
     HERO ENTRANCE ANIMATION TIMELINE
  -------------------------------------------------------------------------- */
  const heroTl = gsap.timeline({ defaults: { ease: 'power3.out', duration: 1 } });

  heroTl
    .from('.glass-chip', { y: -20, opacity: 0, duration: 0.8, delay: 0.2 })
    .from('.hero-title .title-line span', {
      y: '100%',
      opacity: 0,
      stagger: 0.15,
      duration: 1.2,
      ease: 'power4.out'
    }, '-=0.4')
    .from('.hero-description', { y: 20, opacity: 0, duration: 0.8 }, '-=0.6')
    .from('.hero-cta-group .btn', { y: 20, opacity: 0, stagger: 0.1, duration: 0.6 }, '-=0.5')
    .from('.hero-floating-hud', { y: 30, opacity: 0, duration: 0.8 }, '-=0.4')
    .from('.scroll-indicator', { opacity: 0, duration: 0.6 }, '-=0.2');

  /* --------------------------------------------------------------------------
     SECTION 1: KINETIC TYPOGRAPHY SCRUB
  -------------------------------------------------------------------------- */
  const scrubTextEl = document.getElementById('scrubText');
  if (scrubTextEl) {
    // Split text into words wrapped in spans
    const text = scrubTextEl.textContent.trim();
    const words = text.split(/\s+/);
    scrubTextEl.innerHTML = words.map((word) => `<span class="word">${word}</span>`).join(' ');

    const wordElements = scrubTextEl.querySelectorAll('.word');

    gsap.fromTo(
      wordElements,
      { color: 'rgba(255, 255, 255, 0.15)', textShadow: 'none' },
      {
        color: '#ffffff',
        textShadow: '0 0 20px rgba(255, 255, 255, 0.5), 0 0 35px rgba(6, 182, 212, 0.4)',
        stagger: 0.05,
        scrollTrigger: {
          trigger: '#manifesto',
          start: 'top 75%',
          end: 'bottom 45%',
          scrub: 0.8
        }
      }
    );
  }

  /* --------------------------------------------------------------------------
     SECTION 2: PINNED HORIZONTAL SHOWCASE
  -------------------------------------------------------------------------- */
  const horizontalSection = document.getElementById('horizontal-showcase');
  const horizontalTrack = document.getElementById('horizontalTrack');

  if (horizontalSection && horizontalTrack) {
    function getScrollAmount() {
      const trackWidth = horizontalTrack.scrollWidth;
      return -(trackWidth - window.innerWidth + 80);
    }

    const horizontalTween = gsap.to(horizontalTrack, {
      x: getScrollAmount,
      ease: 'none',
      scrollTrigger: {
        trigger: horizontalSection,
        start: 'top top',
        end: () => `+=${horizontalTrack.scrollWidth - window.innerWidth + 500}`,
        pin: true,
        scrub: 1,
        invalidateOnRefresh: true
      }
    });

    // Refresh ScrollTrigger on window resize to update track boundaries
    window.addEventListener('resize', () => {
      ScrollTrigger.refresh();
    });
  }

  /* --------------------------------------------------------------------------
     3D CARD TILT INTERACTION
  -------------------------------------------------------------------------- */
  const tiltCards = document.querySelectorAll('[data-tilt]');

  tiltCards.forEach((card) => {
    const inner = card.querySelector('.card-inner');
    if (!inner) return;

    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const rotateX = ((y - centerY) / centerY) * -10;
      const rotateY = ((x - centerX) / centerX) * 10;

      gsap.to(inner, {
        rotateX: rotateX,
        rotateY: rotateY,
        transformPerspective: 1000,
        ease: 'power1.out',
        duration: 0.3
      });
    });

    card.addEventListener('mouseleave', () => {
      gsap.to(inner, {
        rotateX: 0,
        rotateY: 0,
        ease: 'power2.out',
        duration: 0.6
      });
    });
  });

  /* --------------------------------------------------------------------------
     SECTION 3: METRICS COUNTERS ON SCROLL
  -------------------------------------------------------------------------- */
  const counters = document.querySelectorAll('.counter');

  ScrollTrigger.create({
    trigger: '#metrics',
    start: 'top 70%',
    once: true,
    onEnter: () => {
      counters.forEach((counter) => {
        const target = parseFloat(counter.getAttribute('data-target'));
        const decimals = parseInt(counter.getAttribute('data-decimals') || '0', 10);
        const isShort = counter.getAttribute('data-format') === 'short';

        const obj = { val: 0 };
        gsap.to(obj, {
          val: target,
          duration: 2.2,
          ease: 'power2.out',
          onUpdate: () => {
            if (isShort) {
              const millions = (obj.val / 1000000).toFixed(1);
              counter.textContent = `${millions}M`;
            } else {
              counter.textContent = obj.val.toFixed(decimals);
            }
          }
        });
      });
    }
  });

  /* --------------------------------------------------------------------------
     SECTION 4: ACTIVE SIDE NAV TRACKER
  -------------------------------------------------------------------------- */
  const navDots = document.querySelectorAll('.nav-dot');
  const sections = document.querySelectorAll('section[id]');

  sections.forEach((section) => {
    const id = section.getAttribute('id');
    ScrollTrigger.create({
      trigger: section,
      start: 'top 50%',
      end: 'bottom 50%',
      onToggle: (self) => {
        if (self.isActive) {
          navDots.forEach((dot) => {
            dot.classList.toggle('active', dot.getAttribute('data-section') === id);
          });
        }
      }
    });
  });

  /* --------------------------------------------------------------------------
     CUSTOM CURSOR WITH MAGNETIC PHYSICS
  -------------------------------------------------------------------------- */
  const cursorDot = document.getElementById('cursorDot');
  const cursorRing = document.getElementById('cursorRing');

  let mouseX = -100;
  let mouseY = -100;
  let ringX = -100;
  let ringY = -100;

  window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;

    if (cursorDot) {
      cursorDot.style.left = `${mouseX}px`;
      cursorDot.style.top = `${mouseY}px`;
    }
  });

  // Lerp smoothing loop for cursor ring
  function updateCursor() {
    ringX += (mouseX - ringX) * 0.22;
    ringY += (mouseY - ringY) * 0.22;

    if (cursorRing) {
      cursorRing.style.left = `${ringX}px`;
      cursorRing.style.top = `${ringY}px`;
    }

    requestAnimationFrame(updateCursor);
  }
  requestAnimationFrame(updateCursor);

  // Magnetic hover elements
  const magneticEls = document.querySelectorAll('.magnetic, a, button, input[type="range"], .palette-chip');

  magneticEls.forEach((el) => {
    el.addEventListener('mouseenter', () => {
      if (cursorRing) cursorRing.classList.add('cursor-active');
      if (window.soundEngine) window.soundEngine.playHover();
    });

    el.addEventListener('mouseleave', () => {
      if (cursorRing) cursorRing.classList.remove('cursor-active');
      if (el.classList.contains('magnetic')) {
        gsap.to(el, { x: 0, y: 0, duration: 0.4, ease: 'power2.out' });
      }
    });

    if (el.classList.contains('magnetic')) {
      el.addEventListener('mousemove', (e) => {
        const rect = el.getBoundingClientRect();
        const relX = e.clientX - rect.left - rect.width / 2;
        const relY = e.clientY - rect.top - rect.height / 2;

        gsap.to(el, {
          x: relX * 0.32,
          y: relY * 0.32,
          duration: 0.25,
          ease: 'power1.out'
        });
      });
    }

    el.addEventListener('click', () => {
      if (window.soundEngine) window.soundEngine.playClick();
    });
  });

  /* --------------------------------------------------------------------------
     SECTION 5: KINETIC LAB INTERACTIVE CONTROLS
  -------------------------------------------------------------------------- */
  const densitySlider = document.getElementById('particleDensitySlider');
  const densityVal = document.getElementById('particleDensityVal');
  const speedSlider = document.getElementById('speedSlider');
  const speedVal = document.getElementById('speedVal');
  const connectionSlider = document.getElementById('connectionSlider');
  const connectionVal = document.getElementById('connectionVal');
  const paletteChips = document.querySelectorAll('.palette-chip');
  const themeNameVal = document.getElementById('themeNameVal');
  const warpBurstBtn = document.getElementById('warpBurstBtn');
  const resetLabBtn = document.getElementById('resetLabBtn');

  if (densitySlider && densityVal) {
    densitySlider.addEventListener('input', (e) => {
      const val = e.target.value;
      densityVal.textContent = val;
      if (window.particleEngine) {
        window.particleEngine.setCount(val);
      }
    });
  }

  if (speedSlider && speedVal) {
    speedSlider.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value).toFixed(1);
      speedVal.textContent = `${val}x`;
      if (window.particleEngine) {
        window.particleEngine.setSpeed(val);
      }
    });
  }

  if (connectionSlider && connectionVal) {
    connectionSlider.addEventListener('input', (e) => {
      const val = e.target.value;
      connectionVal.textContent = `${val}px`;
      if (window.particleEngine) {
        window.particleEngine.setConnectionDistance(val);
      }
    });
  }

  paletteChips.forEach((chip) => {
    chip.addEventListener('click', () => {
      paletteChips.forEach((c) => c.classList.remove('active'));
      chip.classList.add('active');
      const palette = chip.getAttribute('data-palette');
      const names = {
        cyan: 'Cyber Cyan',
        violet: 'Neon Violet',
        amber: 'Solar Gold',
        emerald: 'Quantum Green'
      };
      if (themeNameVal) themeNameVal.textContent = names[palette] || palette;
      if (window.particleEngine) {
        window.particleEngine.setPalette(palette);
      }
      if (window.soundEngine) {
        window.soundEngine.playChord([600, 750, 900]);
      }
    });
  });

  if (warpBurstBtn) {
    warpBurstBtn.addEventListener('click', () => {
      if (window.particleEngine) {
        window.particleEngine.triggerWarpBurst();
      }
      if (window.soundEngine) {
        window.soundEngine.playWarpSweep();
      }
    });
  }

  if (resetLabBtn) {
    resetLabBtn.addEventListener('click', () => {
      if (densitySlider) { densitySlider.value = 120; densityVal.textContent = '120'; }
      if (speedSlider) { speedSlider.value = 1.0; speedVal.textContent = '1.0x'; }
      if (connectionSlider) { connectionSlider.value = 110; connectionVal.textContent = '110px'; }
      if (window.particleEngine) {
        window.particleEngine.setCount(120);
        window.particleEngine.setSpeed(1.0);
        window.particleEngine.setConnectionDistance(110);
        window.particleEngine.setPalette('cyan');
      }
      paletteChips.forEach((c) => c.classList.toggle('active', c.getAttribute('data-palette') === 'cyan'));
      if (themeNameVal) themeNameVal.textContent = 'Cyber Cyan';
    });
  }

  /* --------------------------------------------------------------------------
     LIVE TELEMETRY HUD & FOOTER TIME
  -------------------------------------------------------------------------- */
  const liveFps = document.getElementById('liveFps');
  const liveLatency = document.getElementById('liveLatency');
  const footerClock = document.getElementById('footerClock');

  function updateTelemetryClock() {
    // Dynamic subtle jitter to simulate real-time sensor polling
    if (liveFps) {
      const randFps = 118 + Math.floor(Math.random() * 5);
      liveFps.textContent = randFps > 120 ? '120' : randFps;
    }
    if (liveLatency) {
      const randLat = (0.34 + Math.random() * 0.08).toFixed(2);
      liveLatency.textContent = randLat;
    }

    if (footerClock) {
      const now = new Date();
      const utcString = now.toUTCString().split(' ')[4] || '';
      footerClock.textContent = `UTC ${utcString}`;
    }
  }

  setInterval(updateTelemetryClock, 1000);
  updateTelemetryClock();
});
