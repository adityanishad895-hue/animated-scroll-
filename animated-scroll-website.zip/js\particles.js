/**
 * AETHERIA // KINETIC PARTICLE ENGINE
 * High-performance canvas-based particle network with scroll-velocity warp dynamics
 */

class ParticleEngine {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');

    // System parameters
    this.config = {
      count: 120,
      baseSpeed: 1.0,
      connectionDistance: 110,
      paletteKey: 'cyan',
      warpVelocity: 0, // Injected by scroll or surge button
      maxWarp: 18,
      dpr: Math.min(window.devicePixelRatio || 1, 2)
    };

    // Color Palettes
    this.palettes = {
      cyan: {
        primary: 'rgba(6, 182, 212, ',
        secondary: 'rgba(99, 102, 241, ',
        glow: '#06b6d4'
      },
      violet: {
        primary: 'rgba(168, 85, 247, ',
        secondary: 'rgba(236, 72, 153, ',
        glow: '#a855f7'
      },
      amber: {
        primary: 'rgba(245, 158, 11, ',
        secondary: 'rgba(239, 68, 68, ',
        glow: '#f59e0b'
      },
      emerald: {
        primary: 'rgba(16, 185, 129, ',
        secondary: 'rgba(6, 182, 212, ',
        glow: '#10b981'
      }
    };

    this.particles = [];
    this.mouse = { x: -1000, y: -1000, active: false };
    this.width = 0;
    this.height = 0;
    this.isRunning = true;

    this.init();
  }

  init() {
    this.resize();
    window.addEventListener('resize', () => this.resize());
    window.addEventListener('mousemove', (e) => {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
      this.mouse.active = true;
    });
    window.addEventListener('mouseleave', () => {
      this.mouse.active = false;
    });

    this.spawnParticles();
    this.loop();
  }

  resize() {
    this.width = window.innerWidth;
    this.height = window.innerHeight;
    this.canvas.width = this.width * this.config.dpr;
    this.canvas.height = this.height * this.config.dpr;
    this.ctx.scale(this.config.dpr, this.config.dpr);
  }

  spawnParticles() {
    this.particles = [];
    for (let i = 0; i < this.config.count; i++) {
      this.particles.push({
        x: Math.random() * this.width,
        y: Math.random() * this.height,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        radius: Math.random() * 2 + 1,
        colorType: Math.random() > 0.4 ? 'primary' : 'secondary',
        alpha: Math.random() * 0.5 + 0.3,
        pulseSpeed: Math.random() * 0.02 + 0.01,
        angle: Math.random() * Math.PI * 2
      });
    }

    const liveCounter = document.getElementById('liveParticleCount');
    if (liveCounter) {
      liveCounter.textContent = this.config.count.toLocaleString();
    }
  }

  setCount(newCount) {
    this.config.count = parseInt(newCount, 10);
    this.spawnParticles();
  }

  setSpeed(speedMultiplier) {
    this.config.baseSpeed = parseFloat(speedMultiplier);
  }

  setConnectionDistance(dist) {
    this.config.connectionDistance = parseFloat(dist);
  }

  setPalette(name) {
    if (this.palettes[name]) {
      this.config.paletteKey = name;
    }
  }

  triggerWarpBurst() {
    this.config.warpVelocity = this.config.maxWarp;
  }

  injectScrollVelocity(velocity) {
    // Dampened scroll velocity addition
    const added = Math.min(Math.abs(velocity) * 0.35, 12);
    this.config.warpVelocity = Math.max(this.config.warpVelocity, added);
  }

  loop() {
    if (!this.isRunning) return;

    this.ctx.clearRect(0, 0, this.width, this.height);

    // Decay warp velocity smoothly back to 0
    if (this.config.warpVelocity > 0.01) {
      this.config.warpVelocity *= 0.94;
    } else {
      this.config.warpVelocity = 0;
    }

    const currentPalette = this.palettes[this.config.paletteKey];
    const speedFactor = this.config.baseSpeed + this.config.warpVelocity;

    // Draw connecting lines first
    const maxDist = this.config.connectionDistance;
    const pLen = this.particles.length;

    for (let i = 0; i < pLen; i++) {
      const p1 = this.particles[i];

      // Interactive mouse attraction
      if (this.mouse.active) {
        const dxM = this.mouse.x - p1.x;
        const dyM = this.mouse.y - p1.y;
        const distM = Math.hypot(dxM, dyM);
        if (distM < 160) {
          const force = (160 - distM) / 160;
          p1.x -= (dxM / distM) * force * 1.5;
          p1.y -= (dyM / distM) * force * 1.5;
        }
      }

      // Update positions
      p1.x += p1.vx * speedFactor;
      // When warp is high, pull particles upwards/downwards giving a streak effect
      p1.y += (p1.vy + this.config.warpVelocity * 0.4) * speedFactor;

      // Wrap boundaries
      if (p1.x < -20) p1.x = this.width + 20;
      if (p1.x > this.width + 20) p1.x = -20;
      if (p1.y < -20) p1.y = this.height + 20;
      if (p1.y > this.height + 20) p1.y = -20;

      // Draw connection lines to nearby particles
      for (let j = i + 1; j < pLen; j++) {
        const p2 = this.particles[j];
        const dx = p1.x - p2.x;
        const dy = p1.y - p2.y;
        const dist = Math.hypot(dx, dy);

        if (dist < maxDist) {
          const lineAlpha = (1 - dist / maxDist) * 0.22;
          this.ctx.beginPath();
          this.ctx.moveTo(p1.x, p1.y);
          this.ctx.lineTo(p2.x, p2.y);
          this.ctx.strokeStyle = currentPalette.primary + lineAlpha + ')';
          this.ctx.lineWidth = 0.8;
          this.ctx.stroke();
        }
      }

      // Draw particle
      p1.angle += p1.pulseSpeed;
      const radiusPulse = p1.radius + Math.sin(p1.angle) * 0.5;
      const colorBase = p1.colorType === 'primary' ? currentPalette.primary : currentPalette.secondary;

      this.ctx.beginPath();

      if (this.config.warpVelocity > 1) {
        // Render motion trail during warp
        const trailLen = this.config.warpVelocity * 3.5;
        this.ctx.moveTo(p1.x, p1.y - trailLen);
        this.ctx.lineTo(p1.x, p1.y);
        this.ctx.strokeStyle = colorBase + (p1.alpha * 0.8) + ')';
        this.ctx.lineWidth = radiusPulse * 1.2;
        this.ctx.stroke();
      } else {
        this.ctx.arc(p1.x, p1.y, Math.max(0.5, radiusPulse), 0, Math.PI * 2);
        this.ctx.fillStyle = colorBase + p1.alpha + ')';
        this.ctx.shadowBlur = 8;
        this.ctx.shadowColor = currentPalette.glow;
        this.ctx.fill();
        this.ctx.shadowBlur = 0;
      }
    }

    requestAnimationFrame(() => this.loop());
  }
}

// Instantiate globally
window.particleEngine = null;
document.addEventListener('DOMContentLoaded', () => {
  window.particleEngine = new ParticleEngine('particleCanvas');
});
