# ✦ AETHERIA // Next-Gen Kinetic Experience

> An award-winning grade, immersive scrolling animated web experience combining spatial design, inertia-driven physics, real-time particle simulation, and procedural Web Audio synthesis.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Vanilla JavaScript](https://img.shields.io/badge/Vanilla-JavaScript-F7DF1E?logo=javascript&logoColor=black)
![CSS3](https://img.shields.io/badge/CSS3-Modern_Glassmorphism-1572B6?logo=css3)
![GSAP](https://img.shields.io/badge/GSAP-ScrollTrigger-88CE02?logo=greensock)
![Lenis](https://img.shields.io/badge/Smooth_Scroll-Lenis-black)

---

## 🚀 Live Demo & Deployment

This project is built 100% on native web standards (HTML5, Vanilla CSS, Vanilla JavaScript) with zero build tools or bundler requirements. It can be hosted directly on **GitHub Pages**, **Vercel**, or **Netlify** with zero configuration.

### Deploying to GitHub Pages
1. Go to your repository **Settings** on GitHub.
2. In the left sidebar, click **Pages**.
3. Under **Build and deployment** > **Branch**, select `main` (or `master`) and folder `/ (root)`.
4. Click **Save**. Your site will be live at `https://<your-username>.github.io/<repo-name>/` in ~60 seconds!

---

## ✨ Features

- 🌀 **Lenis Smooth Scroll Engine**: Silky momentum scrolling with virtual inertia damping.
- ⚡ **GSAP 3 & ScrollTrigger Pipelines**:
  - Word-by-word kinetic typography scrub in the **Manifesto**.
  - Pinned horizontal camera traverse across **Spatial Module Cores**.
  - Interactive 3D mouse tilt with dynamic light glare.
  - Live benchmark metrics counter animations.
- 🌌 **Kinetic Particle Cosmos (`particles.js`)**:
  - Hardware-accelerated 2D canvas running at up to 120 FPS.
  - **Scroll Velocity Warp**: High scroll velocity pulls particles into dynamic luminous warp streaks.
  - Mouse proximity repulsion/attraction and constellation neural links.
  - 4 Chromatic themes: *Cyber Cyan*, *Neon Violet*, *Solar Gold*, *Quantum Green*.
- 🔊 **Procedural Web Audio Synthesizer (`audio.js`)**:
  - 100% code-generated audio using native Web Audio API oscillators and gain envelopes.
  - Interactive scroll micro-ticks, button click feedback, chord sweeps, and warp burst sound effects.
  - Persistent SFX mute/unmute HUD toggle.
- 🎛️ **Kinetic Lab Playground**:
  - Live UI sliders to tweak particle count (40-280), atmospheric drift speed, and constellation distance on the fly.
  - Interactive "Inject Velocity Warp Surge" trigger.
- 🧲 **Custom Magnetic Glow Cursor**:
  - Dual-ring cursor with lerp smoothing.
  - Bi-directional magnetic attraction on interactive buttons and chips.
- 📱 **Adaptive Responsive Design**: Fully responsive across ultra-wide monitors, laptops, tablets, and smartphones.

---

## 📂 Project Structure

```text
scrolling-animated-website/
├── index.html              # Core HTML structure & semantic layout
├── css/
│   └── style.css           # Design system tokens, glassmorphism & animations
├── js/
│   ├── main.js             # GSAP ScrollTrigger orchestration & UI interactions
│   ├── particles.js        # Real-time interactive canvas particle simulation
│   └── audio.js            # Procedural Web Audio API sound synthesizer
├── server.ps1              # Lightweight zero-dependency local dev server
├── .gitignore              # Ignored files & logs
├── LICENSE                 # MIT License
└── README.md               # Project documentation
```

---

## 💻 Local Development

### Option 1: PowerShell Built-in Server (Windows)
```powershell
.\server.ps1
# Open http://localhost:8088/ in your browser
```

### Option 2: Python HTTP Server (Cross-Platform)
```bash
python -m http.server 8088
# Open http://localhost:8088/
```

### Option 3: VS Code Live Server
Simply right-click `index.html` and select **Open with Live Server**.

---

## 🛠️ Built With

- [GSAP (GreenSock) & ScrollTrigger](https://greensock.com/gsap/) - Advanced timeline choreography
- [Lenis](https://lenis.darkroom.engineering/) - Smooth inertia scrolling
- [Lucide Icons](https://lucide.dev/) - Modern minimalist UI iconography
- [Google Fonts](https://fonts.google.com/) - *Syne*, *Plus Jakarta Sans*, and *JetBrains Mono*
- [Web Audio API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API) - Procedural client-side audio

---

## 📄 License

Distributed under the MIT License. See [LICENSE](LICENSE) for more information.
