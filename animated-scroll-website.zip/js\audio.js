/**
 * AETHERIA // PROCEDURAL AUDIO SYNTHESIZER
 * Web Audio API synthesizer for futuristic micro-interactions without audio file dependencies
 */

class AudioSynthesizer {
  constructor() {
    this.ctx = null;
    this.enabled = false;
    this.lastScrollTick = 0;
    this.initElements();
  }

  initElements() {
    const toggleBtn = document.getElementById('soundToggle');
    const statusText = document.getElementById('soundStatus');
    const soundIcon = document.getElementById('soundIcon');
    const testToneBtn = document.getElementById('testToneBtn');

    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        this.toggleSound();
      });
    }

    if (testToneBtn) {
      testToneBtn.addEventListener('click', () => {
        if (!this.enabled) {
          this.toggleSound(true);
        }
        this.playChord([523.25, 659.25, 783.99, 1046.50]); // C Major 7th harmonic
      });
    }
  }

  ensureContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleSound(forceState) {
    this.ensureContext();
    this.enabled = forceState !== undefined ? forceState : !this.enabled;

    const toggleBtn = document.getElementById('soundToggle');
    const statusText = document.getElementById('soundStatus');
    const soundIcon = document.getElementById('soundIcon');

    if (this.enabled) {
      if (toggleBtn) toggleBtn.classList.add('active');
      if (statusText) statusText.textContent = 'SFX ON';
      if (soundIcon) soundIcon.setAttribute('data-lucide', 'volume-2');
      this.playTone(880, 0.08, 'sine', 0.08);
    } else {
      if (toggleBtn) toggleBtn.classList.remove('active');
      if (statusText) statusText.textContent = 'SFX OFF';
      if (soundIcon) soundIcon.setAttribute('data-lucide', 'volume-x');
    }

    if (window.lucide) {
      window.lucide.createIcons();
    }
  }

  playTone(freq = 440, duration = 0.05, type = 'sine', gainVal = 0.05) {
    if (!this.enabled || !this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {
      // Ignore audio glitches safely
    }
  }

  playHover() {
    if (!this.enabled) return;
    this.playTone(1200 + Math.random() * 200, 0.04, 'sine', 0.02);
  }

  playClick() {
    if (!this.enabled) return;
    this.playTone(600, 0.08, 'triangle', 0.08);
  }

  playWarpSweep() {
    if (!this.enabled || !this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, this.ctx.currentTime + 0.35);

      gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.4);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.4);
    } catch (e) {}
  }

  playScrollTick() {
    if (!this.enabled) return;
    const now = performance.now();
    if (now - this.lastScrollTick < 140) return; // Throttle ticks
    this.lastScrollTick = now;

    this.playTone(320, 0.03, 'sine', 0.015);
  }

  playChord(frequencies) {
    if (!this.enabled || !this.ctx) return;
    frequencies.forEach((freq, index) => {
      setTimeout(() => {
        this.playTone(freq, 0.4, 'sine', 0.04);
      }, index * 45);
    });
  }
}

window.soundEngine = null;
document.addEventListener('DOMContentLoaded', () => {
  window.soundEngine = new AudioSynthesizer();
});
